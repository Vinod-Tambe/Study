/**
 * Auto database setup — runs before `npm run dev`
 *
 * 1. Waits for PostgreSQL to be reachable
 * 2. Tries to start Docker Postgres if not running
 * 3. Runs Prisma generate + migrate deploy (creates DB tables automatically)
 */

import { execSync } from 'child_process';
import { existsSync } from 'fs';
import { resolve } from 'path';
import * as net from 'net';
import * as dotenv from 'dotenv';

const backendDir = resolve(__dirname, '..');
const rootDir = resolve(backendDir, '..');

dotenv.config({ path: resolve(backendDir, '.env') });

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('❌ DATABASE_URL is missing in backend/.env');
  process.exit(1);
}

function parseDatabaseUrl(url: string): { host: string; port: number } {
  const match = url.match(/@([^:/]+):(\d+)\//);
  if (!match) {
    return { host: 'localhost', port: 5432 };
  }
  return { host: match[1], port: parseInt(match[2], 10) };
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

async function isPortOpen(host: string, port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host, port, timeout: 2000 });
    socket.on('connect', () => {
      socket.destroy();
      resolve(true);
    });
    socket.on('error', () => resolve(false));
    socket.on('timeout', () => {
      socket.destroy();
      resolve(false);
    });
  });
}

function tryStartDocker(): void {
  const composeFile = resolve(rootDir, 'docker-compose.yml');
  if (!existsSync(composeFile)) return;

  console.log('🐳 PostgreSQL not reachable — trying docker compose up -d ...');
  try {
    execSync('docker compose up -d', { cwd: rootDir, stdio: 'inherit' });
  } catch {
    console.warn('⚠️  Could not start Docker. Make sure PostgreSQL is running manually.');
  }
}

async function waitForDatabase(host: string, port: number, maxAttempts = 30): Promise<void> {
  for (let i = 1; i <= maxAttempts; i++) {
    if (await isPortOpen(host, port)) {
      console.log(`✅ PostgreSQL is reachable at ${host}:${port}`);
      return;
    }

    if (i === 1) {
      tryStartDocker();
    }

    console.log(`⏳ Waiting for PostgreSQL... (${i}/${maxAttempts})`);
    await sleep(2000);
  }

  throw new Error(
    `PostgreSQL not available at ${host}:${port}.\n` +
      '   Start it with: docker compose up -d\n' +
      '   Or point DATABASE_URL in backend/.env to your running Postgres.'
  );
}

function runPrisma(command: string): void {
  execSync(`npx prisma ${command}`, {
    cwd: backendDir,
    stdio: 'inherit',
    env: { ...process.env },
  });
}

async function main(): Promise<void> {
  console.log('\n📦 Setting up database...\n');

  const { host, port } = parseDatabaseUrl(DATABASE_URL);
  await waitForDatabase(host, port);

  console.log('🔧 Generating Prisma client...');
  runPrisma('generate');

  console.log('🗄️  Running migrations...');
  runPrisma('migrate deploy');

  console.log('\n✅ Database ready!\n');
}

main().catch((err) => {
  console.error('\n❌ Database setup failed:', err.message || err);
  process.exit(1);
});
